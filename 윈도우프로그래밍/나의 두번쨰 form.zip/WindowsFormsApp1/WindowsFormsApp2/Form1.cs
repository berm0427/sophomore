﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        private bool flag;
        public Form1()
        {
            InitializeComponent();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(flag== false)
            {
                label1.Text = "C# 조별과제의 첫 걸음";
                
                string comlist = "컴퓨터의 종류를 살펴보면" +
                " 크게 2가지로 구분할 수 있습니다.\n" +
                "데스크탑 PC와 노트북 PC로 " +
                "선호도는 달라집니다";
                label2.Text = comlist;
                flag = true;

                this.ClientSize = new Size(800, 500);
                Form f2 = new Form2();
                this.AddOwnedForm(f2);
                f2.Show();
            }

            else
            {
                label1.Text = "";
                label2.Text = "";
                flag = false;
            }
        }
    }
}

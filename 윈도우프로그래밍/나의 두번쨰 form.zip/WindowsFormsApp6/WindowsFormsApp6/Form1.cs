﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "c0d1n9" && textBox2.Text == "123456")
            {
                string msg = "로그인 성공";
                MessageBox.Show(msg, "로그인 성공");
            }
            else
            {
                string smg = "아이디 또는 암호를 확인하세요";
                MessageBox.Show(smg, "로그인 실패", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

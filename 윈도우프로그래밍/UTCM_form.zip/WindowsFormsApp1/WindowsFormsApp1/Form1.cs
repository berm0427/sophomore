﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TimeZoneConverter;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Dictionary<string, string> countryToTimezoneMap;

        public Form1()
        {
            InitializeComponent(); // 폼 시작 설정
            InitializeCountryToTimezoneMap(); // UTC 타임존과 국가를 매칭해주는 기본 설정
            utc_info.Text = "국가의 이름을 입력해 주세요\n" +
                "현재는 Korea, USA_NewYork, Japan, UTC 기본 시간만 가능합니다";
            timeLabel.Text = ""; // UTC 타임라벨 초기화
            countryTextBox.KeyDown += countryTextBox_KeyDown; // countryTextBox에 키 입력이 있을 때마다
                                                              // countryTextBox_KeyDown 메서드가 호출되도록 설정하는 것
            timer.Tick += timer_Tick; // 타이머 시간이 흐르도록 설정
            timer.Interval = 1000; // 1초마다 Tick 이벤트 발생
            timer.Start(); // Timer 시작
        }

        private void InitializeCountryToTimezoneMap()
        {
            // 시간대와 국가의 쌍 입력
            countryToTimezoneMap = new Dictionary<string, string>
            {
                { "Korea", "Asia/Seoul" },
                { "USA_NewYork", "America/New_York" },
                { "Japan", "Asia/Tokyo" },
                // 추가적인 국가와 시간대 매핑을 여기에 추가할 수 있습니다.
            };
        }

        private void countryTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                UpdateTime();
                e.SuppressKeyPress = true; // Enter 키를 누를 때 소리를 방지
            }
        }

        private void timer_Tick(object sender, EventArgs e) // 타이머 간격이 흐를때 진행하는 작업
        {
            UpdateTime(); // 시간 업데이트
        }

        private void UpdateTime() // 시간 업데이트
        {
            string countryInput = countryTextBox.Text.Trim(); // 텍스트 박스에서 공백을 제거하고 변수에 저장 
            DateTime currentTime = DateTime.UtcNow; // UTC 타임을 받아 저장

            if (!string.IsNullOrWhiteSpace(countryInput)) // 공백시 에러 처리
            {
                if (countryToTimezoneMap.TryGetValue(countryInput, out var timezoneId)) // countryinput을 키로 갖는 값을
                                                                                        // 가져와서 timezoneId에 저장
                {
                    try
                    {
                        TimeZoneInfo timeZoneInfo = TZConvert.GetTimeZoneInfo(timezoneId);
                        currentTime = TimeZoneInfo.ConvertTimeFromUtc(currentTime, timeZoneInfo);
                        timeLabel.Text = $"{countryInput} Time: {currentTime:yyyy-MM-dd tt hh:mm:ss}";
                    }
                    catch (TimeZoneNotFoundException)
                    {
                        timeLabel.Text = "해당하는 타임존 정보가 없습니다";
                    }
                    catch (InvalidTimeZoneException)
                    {
                        timeLabel.Text = "잘못된 타임존 입니다";
                    }
                }
                else
                {
                    timeLabel.Text = "국가 이름이 잘못되었습니다";
                }
            }
            else
            {
                // 국가 이름이 입력되지 않았을 때 UTC 시간을 표시
                timeLabel.Text = $"UTC Time: {currentTime:yyyy-MM-dd tt HH:mm:ss}";
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TimeZoneConverter;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Dictionary<string, string> countryToTimezoneMap;

        public Form1()
        {
            InitializeComponent();
            InitializeCountryToTimezoneMap();
            utc_info.Text = "국가의 이름을 입력해 주세요\n" +
                "현재는 Korea, USA, Japan, UTC 기본 시간만 가능합니다";
            timeLabel.Text = "";
            countryTextBox.KeyDown += countryTextBox_KeyDown;
            timer.Tick += timer_Tick;
            timer.Interval = 1000; // 1초마다 Tick 이벤트 발생
            timer.Start(); // Timer 시작
        }

        private void InitializeCountryToTimezoneMap()
        {
            // 시간대와 국가의 쌍 입력
            countryToTimezoneMap = new Dictionary<string, string>
            {
                { "Korea", "Asia/Seoul" },
                { "USA", "America/New_York" },
                { "Japan", "Asia/Tokyo" },
                // 추가적인 국가와 시간대 매핑을 여기에 추가할 수 있습니다.
            };
        }

        private void countryTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                UpdateTime();
                e.SuppressKeyPress = true; // Enter 키를 누를 때 소리를 방지
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            UpdateTime();
        }

        private void UpdateTime()
        {
            string countryInput = countryTextBox.Text.Trim();
            DateTime currentTime = DateTime.UtcNow;

            if (!string.IsNullOrWhiteSpace(countryInput))
            {
                if (countryToTimezoneMap.TryGetValue(countryInput, out var timezoneId))
                {
                    try
                    {
                        TimeZoneInfo timeZoneInfo = TZConvert.GetTimeZoneInfo(timezoneId);
                        currentTime = TimeZoneInfo.ConvertTimeFromUtc(currentTime, timeZoneInfo);
                        timeLabel.Text = $"{countryInput} Time: {currentTime:yyyy-MM-dd HH:mm:ss}";
                    }
                    catch (TimeZoneNotFoundException)
                    {
                        timeLabel.Text = "해당하는 타임존 정보가 없습니다";
                    }
                    catch (InvalidTimeZoneException)
                    {
                        timeLabel.Text = "잘못된 타임존 입니다";
                    }
                }
                else
                {
                    timeLabel.Text = "국가 이름이 잘못되었습니다";
                }
            }
            else
            {
                // 국가 이름이 입력되지 않았을 때 UTC 시간을 표시
                timeLabel.Text = $"UTC Time: {currentTime:yyyy-MM-dd HH:mm:ss}";
            }
        }
    }
}

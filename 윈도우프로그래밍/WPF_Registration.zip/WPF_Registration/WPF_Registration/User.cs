﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Registration
{
    public class User
    {
        [System.ComponentModel.DataAnnotations.Key]
        public String Id { get; set; }
        public string Pw { get; set; }
    }
}

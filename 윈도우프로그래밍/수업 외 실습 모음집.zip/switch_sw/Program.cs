﻿using System;
using System.Threading.Channels;

static string Classify(double measurement) => measurement switch
{
    < -40.0 => "Too low",
    >= -40.0 and < 0 => "low",
    >= 0 and < 10.0 => "Acceptable",
    >= 10.0 and < 20.0 => "High",
    >= 20 => "Too High",
    double.NaN => "Unknown",
};

var cl =Classify(40);

Console.WriteLine(cl);
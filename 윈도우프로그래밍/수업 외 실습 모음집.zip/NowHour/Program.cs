﻿using System;

namespace NowHour
{
    class Program
    {
        static void Main(string[] args)
        {
            if (DateTime.Now.Hour >= 6 && DateTime.Now.Hour <= 11)
            {
                Console.WriteLine("아침 먹을 시간");
            }
            
            else if (DateTime.Now.Hour >= 12 && DateTime.Now.Hour <= 15)
            {
                Console.WriteLine("점심 먹을 시간");
            }
            
            else if (DateTime.Now.Hour >= 16 && DateTime.Now.Hour <= 19)
            {
                Console.WriteLine("저녁 먹을 시간");
            }
            else if (DateTime.Now.Hour >= 20 && DateTime.Now.Hour <= 24)
            {
                Console.WriteLine("아식 먹을 시간");
            }

            else
            {
                Console.WriteLine("잘 시간");
            }
        }
    }
}
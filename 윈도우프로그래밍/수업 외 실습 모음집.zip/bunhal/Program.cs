﻿using System;

namespace bunhal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("입력: ");
            String line = Console.ReadLine();

            if (line.Contains("안녕"))
            {
                Console.WriteLine("안녕하세요 저는 ");
            }

            else
            {
                Console.WriteLine("지금부터는 제가 정리한 글을 보면서 이야기 하겠습니다");
            }
        }
    }
}


﻿using System;

namespace EnumTest
{
    public class Program
    {
        enum Days
        {
            SaturDay,
            SunDay,
            MonDay,
            TuesDay,
            WednesDay,
            ThursDay,
            FriDay
        }

        enum Season
        {
            Spring,
            Summer,
            Autumn,
            Winter
        }

        public static void Main(string[] args)
        {
            Type weekDays = typeof(Days);

            Console.WriteLine("The Days of the Week, and Their Corresponding Values in Days Enum Are: ");

            foreach (string s in Enum.GetNames(weekDays))
            {
                Console.WriteLine(s);
            }
            Console.WriteLine();
            foreach (var item in Enum.GetValues(typeof(Season)))
            {
                Console.WriteLine(item);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_BMICalculator
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_click(object sender, RoutedEventArgs e)
        {
            if(height_input.Text == "" || weight_input.Text == "")
            {
                MessageBoxResult res = MessageBox.Show(
                    "키와 체중을 입력하세요",
                    "경고",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                return ;
            }

            double h = Convert.ToDouble(height_input.Text) / 100.0;
            double w = Double.Parse(weight_input.Text);
            Double bmi = w / (h * h);
            BMI_print.Text = String.Format("{0:F2}", bmi);

            if (bmi > 35)
            {
                result_print.Text = "3단계 비만";
            }
            else if (bmi < 35 && bmi >= 30)
            {
                result_print.Text = "2단계 비만";
            }
            else if (bmi < 30 && bmi >= 25)
            {
                result_print.Text = "1단계 비만";
            }
            else if (bmi < 25 && bmi >= 23)
            {
                result_print.Text = "비만 전 단계";
            }
            else
            {
                result_print.Text = "정상 체중";
            }
        }
    }
}

import java.util.Vector;


public class PrintVectorEx
{
	public static void PrintVector(Vector<Integer>v)
	{
		for(int i = 0; i<v.size(); i++)
		{
			int n = v.get(i);
			System.out.println(n);
		}
	}
	public static void main(String[] args)
	{
		Vector <Integer> v = new Vector<Integer>();
		
		v.add(5); // 5 삽입
		v.add(4);
		v.add(-1);
		PrintVector(v);
		
		var v1 = new Vector<Integer>();
		v1.addAll(v);
		PrintVector(v1);
	}
}
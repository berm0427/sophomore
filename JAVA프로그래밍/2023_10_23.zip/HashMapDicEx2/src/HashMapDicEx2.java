import java.util.*;
public class HashMapDicEx2 {
	public static void main(String[] args) {
		HashMap<String, String> dic = new HashMap<String, String>(); // 해시맵 생성
		
		// 3개의 (key, value) 쌍을 dic에 저장
		dic.put("baby", "아기"); // "baby"는 key, "아기"은 value
		dic.put("love", "사랑"); 
		dic.put("apple", "사과");
		
		// dic 해시맵에 들어있는 모든 (Key, value) 출력
		
		Iterator<String> it = dic.keySet().iterator();
		while (it.hasNext()) 
		{
			String key = it.next();
			String value = dic.get(key);
			System.out.println("(" + key + "," + value + ")");
			
		}
		System.out.println();
		
		// 영어 단어를 입력 받고 한글 단어 검색
		Scanner scanner = new Scanner(System.in);
		while (true)
		{
			System.out.print("찾고 싶은 단어는?");
			String eng = scanner.next();
			// 해시맵에서 '키' eng의 '값' kor 검색
			String kor = dic.get(eng);
			if(kor == null || !(eng.equals(eng))) 
				System.out.println(eng + "는 없는 단어 입니다.");
			else if (!(eng.equals(eng))|| kor != null)
				System.out.println(kor); 
			if(eng.equals("exit")) 
			{
				System.out.println("종료합니다...");
				break;
			}
		}
		scanner.close();
	}
}